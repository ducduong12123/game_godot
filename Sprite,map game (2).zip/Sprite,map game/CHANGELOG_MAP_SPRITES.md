# Map/Sprite/UI redesign notes

Đã chỉnh trực tiếp trong project:

- Tạo sprite PNG mới trong `assets/custom_sprites/` cho player, item, terminal, door và repair station.
- Chuyển item placeholder hình tròn sang sprite riêng trong `scripts/modules/world_module.gd`.
- Thiết kế lại map theo các khoang: Engineering Bay, Storage, Bio Lab, Reactor Core, Main Corridor, Operations, Airlock/Escape.
- Bật lại collision logic trong `world_module.gd`: player chỉ đi trong vùng walkable và bị chặn bởi các khung collision.
- Thêm scene `scenes/collision_frames.tscn` chứa các `StaticBody2D/CollisionShape2D` tương ứng với khung tường/vật cản để dễ mở trong Godot và chỉnh bằng editor.
- Thêm visual feedback:
  - Nhặt item: popup thông báo + item biến mất.
  - Mở cửa: đổi marker door + popup thành công.
  - Craft thành công/thất bại: popup xanh/đỏ.
  - Puzzle đúng/sai: popup xanh/đỏ.
  - Nhiệm vụ hoàn thành: popup log.
  - Game over/win: panel kết quả rõ ràng.

File chính đã sửa:

- `scripts/modules/world_module.gd`
- `scripts/content/map_data.gd`
- `scripts/content/game_data.gd`
- `scripts/modules/ui_module.gd`
- `scripts/modules/gameplay_module.gd`
- `scripts/main.gd`
- `scenes/main.tscn`
- `scenes/collision_frames.tscn`
