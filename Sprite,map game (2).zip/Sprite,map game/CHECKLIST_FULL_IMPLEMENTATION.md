# Checklist sửa đủ 100%

## Sprite
- Player đã có idle + walk theo 3 hướng: down, up, side.
- Item trên map đã dùng sprite riêng cho toàn bộ item yêu cầu.
- Terminal đã dùng sprite riêng.
- Door đã có đủ 3 trạng thái:
  - door_closed.png: cửa thường/chưa mở
  - door_locked.png: cửa khóa
  - door_open.png: cửa đã mở
- Repair station/system object đã dùng sprite riêng.

## UI
- HUD sinh tồn có Pin, O2, HP, nhiệt độ, nước, độ no, lượt hiện tại.
- Bảng nhiệm vụ có mục tiêu lớn, nhiệm vụ con, việc cần làm tiếp theo.
- Inventory popup có danh sách item đang có.
- Crafting panel có chọn công thức, nguyên liệu, nút chế tạo.
- Puzzle popup đã có câu hỏi, đáp án, hint và kết quả đúng/sai ngay trong panel.
- AI chat panel có ô nhập, nút gửi, log chat, nút đóng.

## Visual Feedback
- Nhặt item: item biến mất và hiện thông báo.
- Mở cửa: door đổi trạng thái closed/locked/open.
- Craft thành công/thất bại: có thông báo rõ.
- Puzzle đúng: thông báo xanh và tăng repair.
- Puzzle sai: thông báo đỏ và mất HP.
- Nhiệm vụ con hoàn thành: có log “Hoàn thành: ...”.
- Game over / win screen: có màn hình kết quả.

## Map + Collision
- Map đã được chỉnh thành nhiều khoang rõ ràng.
- Có collision frames trong scenes/collision_frames.tscn.
- Logic di chuyển chặn player đi xuyên khung/tường/cửa chưa mở.
