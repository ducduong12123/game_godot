extends RefCounted

var game
var _ui_font: Font = null
var _textures := {}

const ITEM_TEXTURES := {
	"Alloy Plate": "res://assets/custom_sprites/alloy_plate.png",
	"Electrolyte Pack": "res://assets/custom_sprites/electrolyte_pack.png",
	"Superconductor Wire": "res://assets/custom_sprites/superconductor_wire.png",
	"Backup Battery": "res://assets/custom_sprites/backup_battery.png",
	"Portable Oxygen": "res://assets/custom_sprites/portable_oxygen.png",
	"Bio Gel": "res://assets/custom_sprites/bio_gel.png",
	"Air Filter Module": "res://assets/custom_sprites/air_filter_module.png",
	"Navigation Board": "res://assets/custom_sprites/navigation_board.png",
	"Reactor Core": "res://assets/custom_sprites/reactor_core.png",
	"Level 1 Access Card": "res://assets/custom_sprites/level_1_access_card.png",
	"Engineer Log": "res://assets/custom_sprites/engineer_log.png",
}


func setup(game_ref) -> void:
	game = game_ref
	_ui_font = _load_font_from_file("res://assets/fonts/BeVietnamPro-Regular.ttf")
	_load_textures()


func _load_textures() -> void:
	_textures["terminal"] = load("res://assets/custom_sprites/terminal.png")
	_textures["door_open"] = load("res://assets/custom_sprites/door_open.png")
	_textures["door_locked"] = load("res://assets/custom_sprites/door_locked.png")
	_textures["door_closed"] = load("res://assets/custom_sprites/door_closed.png")
	_textures["repair_station"] = load("res://assets/custom_sprites/repair_station.png")
	for direction in ["down", "up", "side"]:
		_textures["player_idle_%s" % direction] = load("res://assets/custom_sprites/player_idle_%s.png" % direction)
		_textures["player_walk_%s_1" % direction] = load("res://assets/custom_sprites/player_walk_%s_1.png" % direction)
		_textures["player_walk_%s_2" % direction] = load("res://assets/custom_sprites/player_walk_%s_2.png" % direction)
	for item_name in ITEM_TEXTURES.keys():
		_textures[item_name] = load(str(ITEM_TEXTURES[item_name]))


func draw() -> void:
	_draw_background()
	_draw_rooms()
	_draw_floor_grid()
	_draw_collision_frames()
	_draw_room_labels()
	_draw_repair_stations()
	_draw_doors()
	_draw_terminal()
	_draw_items()
	_draw_player()


func try_move_player(delta_move: Vector2) -> void:
	var next_pos = game.player_pos + delta_move
	next_pos.x = clampf(next_pos.x, game.WORLD_RECT.position.x + 12.0, game.WORLD_RECT.position.x + game.WORLD_RECT.size.x - 12.0)
	next_pos.y = clampf(next_pos.y, game.WORLD_RECT.position.y + 12.0, game.WORLD_RECT.position.y + game.WORLD_RECT.size.y - 12.0)
	if _can_move_to(next_pos):
		game.player_pos = next_pos


func _can_move_to(next_pos: Vector2) -> bool:
	var body_rect := Rect2(next_pos - Vector2(13, 18), Vector2(26, 32))
	var inside_walkable := false
	for walk_rect in game.MapData.walkable_rects():
		if walk_rect.grow(-8.0).has_point(next_pos):
			inside_walkable = true
			break
	if not inside_walkable:
		return false
	for obstacle in game.MapData.collision_rects():
		if obstacle.intersects(body_rect):
			if _obstacle_is_open_door_gap(obstacle, next_pos):
				continue
			return false
	return true


func _obstacle_is_open_door_gap(_obstacle: Rect2, pos: Vector2) -> bool:
	for door_id in game.doors.keys():
		if not door_is_open(door_id):
			continue
		var door: Dictionary = game.doors[door_id]
		var center := game.MapData.door_center(door)
		if pos.distance_to(center) <= 45.0:
			return true
	return false


func door_is_open(door_id: String) -> bool:
	return door_state(door_id) == "open"


func door_state(door_id: String) -> String:
	var door: Dictionary = game.doors[door_id]
	var required_item = str(door.get("required_item", ""))
	if bool(door.get("opened", false)):
		return "open"
	if required_item != "" and not bool(door.get("unlocked", false)):
		return "locked"
	return "closed"


func nearest_door_id() -> String:
	var nearest = ""
	var best_dist = game.INTERACT_RANGE
	for door_id in game.doors.keys():
		var dist = game.player_pos.distance_to(game.MapData.door_center(game.doors[door_id]))
		if dist <= best_dist:
			best_dist = dist
			nearest = door_id
	return nearest


func nearest_locked_door_id() -> String:
	for door_id in game.doors.keys():
		if door_state(door_id) != "locked":
			continue
		var dist = game.player_pos.distance_to(game.MapData.door_center(game.doors[door_id]))
		if dist <= game.INTERACT_RANGE:
			return door_id
	return ""


func nearest_closed_door_id() -> String:
	for door_id in game.doors.keys():
		if door_state(door_id) != "closed":
			continue
		var dist = game.player_pos.distance_to(game.MapData.door_center(game.doors[door_id]))
		if dist <= game.INTERACT_RANGE:
			return door_id
	return ""


func update_near_item() -> void:
	game.near_item_index = _find_nearest_uncollected_item()


func _find_nearest_uncollected_item() -> int:
	var best_dist := INF
	var nearest := -1
	for i in range(game.items.size()):
		if bool(game.items[i]["collected"]):
			continue
		var dist: float = game.player_pos.distance_to(game.items[i]["pos"])
		if dist <= game.INTERACT_RANGE and dist < best_dist:
			best_dist = dist
			nearest = i
	return nearest


func room_name_at_player() -> String:
	return game.MapData.room_name_at(game.player_pos)


func _draw_background() -> void:
	game.draw_rect(Rect2(Vector2.ZERO, game.get_viewport_rect().size), Color(0.035, 0.055, 0.09), true)
	var wr: Rect2 = game.WORLD_RECT
	game.draw_rect(wr.grow(18), Color(0.015, 0.025, 0.04, 0.95), true)


func _draw_rooms() -> void:
	for room in game.rooms:
		var room_rect: Rect2 = room["rect"]
		game.draw_rect(room_rect, room["color"], true)
		game.draw_rect(room_rect, Color(0.55, 0.70, 0.86, 0.75), false, 2.0)
		game.draw_rect(room_rect.grow(-10.0), Color(0.80, 0.95, 1.0, 0.06), false, 1.0)


func _draw_floor_grid() -> void:
	var grid_color := Color(0.35, 0.55, 0.70, 0.14)
	var world_rect: Rect2 = game.WORLD_RECT
	for x in range(int(world_rect.position.x) + 40, int(world_rect.position.x + world_rect.size.x), 80):
		game.draw_line(Vector2(x, world_rect.position.y), Vector2(x, world_rect.position.y + world_rect.size.y), grid_color, 1.0)
	for y in range(int(world_rect.position.y) + 40, int(world_rect.position.y + world_rect.size.y), 80):
		game.draw_line(Vector2(world_rect.position.x, y), Vector2(world_rect.position.x + world_rect.size.x, y), grid_color, 1.0)


func _draw_collision_frames() -> void:
	# Vẽ rõ các khung collision để dễ chỉnh trong editor.
	for rect in game.MapData.collision_rects():
		game.draw_rect(rect, Color(0.02, 0.025, 0.035, 0.88), true)
		game.draw_rect(rect, Color(0.70, 0.80, 0.92, 0.55), false, 1.5)


func _draw_repair_stations() -> void:
	for prop in game.MapData.decorative_props():
		var p: Vector2 = prop["pos"]
		_draw_texture_centered("repair_station", p, Vector2(0.78, 0.78))
		if _ui_font != null:
			game.draw_string(_ui_font, p + Vector2(-58, 48), str(prop["name"]), HORIZONTAL_ALIGNMENT_CENTER, 120.0, 11, Color(0.86, 0.95, 1.0, 0.86))


func _draw_doors() -> void:
	for door_id in game.doors.keys():
		var door: Dictionary = game.doors[door_id]
		var state := door_state(door_id)
		var center: Vector2 = game.MapData.door_center(door)
		var key := "door_closed"
		var marker_color := Color(0.72, 0.80, 0.90, 0.26)
		if state == "open":
			key = "door_open"
			marker_color = Color(0.20, 0.85, 0.45, 0.28)
		elif state == "locked":
			key = "door_locked"
			marker_color = Color(0.95, 0.20, 0.20, 0.32)
		var scale := Vector2(0.72, 0.72)
		_draw_texture_centered(key, center, scale)
		var door_rect := _door_rect_from_dict(door)
		game.draw_rect(door_rect, marker_color, true)
		if _ui_font != null:
			var label := "%s [%s]" % [str(door.get("name", "")), state]
			game.draw_string(_ui_font, center + Vector2(14, -18), label, HORIZONTAL_ALIGNMENT_LEFT, -1.0, 12, Color(0.96, 0.98, 1.0))


func _door_rect_from_dict(door: Dictionary) -> Rect2:
	var line_val := float(door.get("line", 0.0))
	var start_val := float(door.get("start", 0.0))
	var end_val := float(door.get("end", 0.0))
	if str(door.get("orientation", "")) == "vertical":
		return Rect2(line_val - 9.0, start_val, 18.0, end_val - start_val)
	return Rect2(start_val, line_val - 9.0, end_val - start_val, 18.0)


func _draw_terminal() -> void:
	_draw_texture_centered("terminal", game.terminal_pos, Vector2(0.86, 0.86))
	game.draw_circle(game.terminal_pos, 30.0, Color(0.10, 0.95, 0.90, 0.12))
	if _ui_font != null:
		game.draw_string(_ui_font, game.terminal_pos + Vector2(-42, 48), "Main Terminal", HORIZONTAL_ALIGNMENT_CENTER, 120.0, 12, Color(0.90, 1.0, 0.98))


func _draw_items() -> void:
	for item in game.items:
		if bool(item["collected"]):
			continue
		var p: Vector2 = item["pos"]
		var name := str(item["name"])
		game.draw_circle(p, 22.0, Color(0.95, 0.95, 1.0, 0.10))
		_draw_texture_centered(name, p, Vector2(0.56, 0.56))
		if game.player_pos.distance_to(p) <= game.INTERACT_RANGE and _ui_font != null:
			game.draw_string(_ui_font, p + Vector2(-70, 38), name, HORIZONTAL_ALIGNMENT_CENTER, 140.0, 11, Color(1.0, 1.0, 0.86))


func _draw_player() -> void:
	var direction := "down"
	if abs(game.last_move_dir.x) > abs(game.last_move_dir.y):
		direction = "side"
	elif game.last_move_dir.y < -0.1:
		direction = "up"

	var key := "player_idle_%s" % direction
	if game.player_is_moving:
		var frame := 1 + (int(game.player_anim_time * 8.0) % 2)
		key = "player_walk_%s_%d" % [direction, frame]
	_draw_texture_centered(key, game.player_pos + Vector2(0, -10), Vector2(0.68, 0.68))
	game.draw_circle(game.player_pos, 24.0, Color(1.0, 0.82, 0.35, 0.10))


func _draw_texture_centered(key: String, pos: Vector2, scale: Vector2 = Vector2.ONE) -> void:
	var tex: Texture2D = _textures.get(key, null)
	if tex == null:
		return
	var size := tex.get_size() * scale
	game.draw_texture_rect(tex, Rect2(pos - size * 0.5, size), false)


func _draw_room_labels() -> void:
	if _ui_font == null:
		return
	for room in game.rooms:
		var room_rect: Rect2 = room["rect"]
		game.draw_string(_ui_font, room_rect.position + Vector2(14, 24), str(room["name"]), HORIZONTAL_ALIGNMENT_LEFT, -1.0, 15, Color(0.92, 0.97, 1.0, 0.88))


func _load_font_from_file(path: String) -> Font:
	var bytes: PackedByteArray = FileAccess.get_file_as_bytes(path)
	if bytes.is_empty():
		return ThemeDB.fallback_font
	var font_file := FontFile.new()
	if font_file.has_method("load_dynamic_font"):
		var err := int(font_file.call("load_dynamic_font", path))
		if err == OK:
			return font_file
	for prop in font_file.get_property_list():
		if typeof(prop) == TYPE_DICTIONARY and str(prop.get("name", "")) == "data":
			font_file.set("data", bytes)
			return font_file
	return ThemeDB.fallback_font
