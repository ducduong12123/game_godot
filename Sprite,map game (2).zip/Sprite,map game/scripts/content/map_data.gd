extends RefCounted

const WORLD_RECT := Rect2(-2420, -1090, 2540, 1040)
const WALL_X := -960.0
const WALL_Y := -520.0
const TERMINAL_POS := Vector2(-450, -470)


static func room_rects() -> Array:
	return [
		{"id":"engineering","name":"Engineering Bay","rect":Rect2(-2360,-1030,640,430),"color":Color(0.18,0.23,0.30,0.82)},
		{"id":"storage","name":"Storage / Materials","rect":Rect2(-1680,-1030,560,430),"color":Color(0.16,0.27,0.25,0.82)},
		{"id":"medlab","name":"Bio Lab","rect":Rect2(-1080,-1030,540,430),"color":Color(0.15,0.28,0.34,0.82)},
		{"id":"reactor","name":"Reactor Core","rect":Rect2(-500,-1030,560,430),"color":Color(0.30,0.20,0.16,0.82)},
		{"id":"hallway","name":"Main Corridor","rect":Rect2(-2360,-570,1720,250),"color":Color(0.12,0.16,0.23,0.76)},
		{"id":"operations","name":"Operations","rect":Rect2(-600,-570,330,250),"color":Color(0.18,0.25,0.22,0.82)},
		{"id":"decon","name":"Airlock / Escape","rect":Rect2(-230,-700,350,380),"color":Color(0.26,0.25,0.17,0.82)},
	]


static func decorative_props() -> Array:
	return [
		{"name":"O2 Repair Station","pos":Vector2(-885,-830),"kind":"station"},
		{"name":"Power Repair Station","pos":Vector2(-1815,-835),"kind":"station"},
		{"name":"Reactor Repair Station","pos":Vector2(-345,-830),"kind":"station"},
		{"name":"Escape Repair Station","pos":Vector2(-80,-500),"kind":"station"},
	]


static func collision_rects() -> Array:
	# Các khung này vừa là vật cản code, vừa tương ứng với CollisionShape2D trong scene map.
	return [
		Rect2(-2420,-1090,2540,28), Rect2(-2420,-78,2540,28),
		Rect2(-2420,-1090,28,1040), Rect2(92,-1090,28,1040),
		Rect2(-1705,-1070,26,520), Rect2(-1110,-1070,26,520), Rect2(-535,-1070,26,520),
		Rect2(-2420,-600,1800,26), Rect2(-620,-600,740,26),
		Rect2(-2420,-318,1800,26), Rect2(-620,-318,740,26),
		Rect2(-260,-720,26,430),
		Rect2(-2200,-900,150,48), Rect2(-1525,-975,140,46), Rect2(-985,-745,180,44),
		Rect2(-420,-910,160,52), Rect2(-520,-505,120,44), Rect2(-75,-660,90,58),
	]


static func walkable_rects() -> Array:
	return room_rects().map(func(room): return room["rect"])


static func create_doors() -> Dictionary:
	return {
		"door_storage_biolab":{"id":"door_storage_biolab","name":"Cửa A1","orientation":"vertical","line":-1110.0,"start":-875.0,"end":-755.0,"required_item":"Level 1 Access Card","unlocked":false,"opened":false},
		"door_hall_decon":{"id":"door_hall_decon","name":"Cửa B2","orientation":"vertical","line":-260.0,"start":-560.0,"end":-450.0,"required_item":"Engineer Log","unlocked":false,"opened":false},
		"door_engineering_hall":{"id":"door_engineering_hall","name":"Cửa C1","orientation":"horizontal","line":-600.0,"start":-2050.0,"end":-1880.0,"required_item":"","unlocked":true,"opened":false},
		"door_storage_hall":{"id":"door_storage_hall","name":"Cửa C2","orientation":"horizontal","line":-600.0,"start":-1500.0,"end":-1350.0,"required_item":"","unlocked":true,"opened":false},
		"door_biolab_hall":{"id":"door_biolab_hall","name":"Cửa C3","orientation":"horizontal","line":-600.0,"start":-930.0,"end":-780.0,"required_item":"","unlocked":true,"opened":false},
		"door_ops_decon":{"id":"door_ops_decon","name":"Cửa C4","orientation":"vertical","line":-260.0,"start":-430.0,"end":-340.0,"required_item":"","unlocked":true,"opened":false},
	}


static func door_center(door: Dictionary) -> Vector2:
	var start_val := float(door.get("start", 0.0))
	var end_val := float(door.get("end", 0.0))
	var mid: float = (start_val + end_val) * 0.5
	if str(door.get("orientation", "")) == "vertical":
		return Vector2(float(door.get("line", WALL_X)), mid)
	return Vector2(mid, float(door.get("line", WALL_Y)))


static func room_name_at(pos: Vector2) -> String:
	for room in room_rects():
		if (room["rect"] as Rect2).has_point(pos):
			return str(room["name"])
	return "Vùng chuyển tiếp"
