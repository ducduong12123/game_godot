@echo off
echo Copy this patch folder's contents into your Godot project root.
echo The Godot project root is the folder containing project.godot.
echo.
echo This script is only an instruction helper and does not auto-copy files.
pause
