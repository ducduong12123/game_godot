# Godot 100% Checklist Patch

Đây là gói tách riêng các phần đã sửa/thêm so với file game gốc.

## Cách dùng

1. Giải nén file game gốc của bạn.
2. Mở thư mục project gốc, tức thư mục có file `project.godot`.
3. Copy toàn bộ nội dung trong gói patch này vào thư mục project gốc.
4. Chọn Replace/Overwrite nếu hệ thống hỏi ghi đè file.
5. Mở lại project bằng Godot.

## Nội dung patch

Patch này không chứa toàn bộ game gốc. Nó chỉ chứa:
- 7 file đã sửa:
  - `scenes/main.tscn`
  - `scripts/content/game_data.gd`
  - `scripts/content/map_data.gd`
  - `scripts/main.gd`
  - `scripts/modules/gameplay_module.gd`
  - `scripts/modules/ui_module.gd`
  - `scripts/modules/world_module.gd`

- Các file mới:
  - sprite item/player/door/terminal/repair station trong `assets/custom_sprites/`
  - collision scene: `scenes/collision_frames.tscn`
  - checklist/ghi chú thay đổi

## Checklist đã đủ

- Player có idle + walk theo hướng.
- Item placeholder đã chuyển thành sprite.
- Terminal có sprite.
- Door có 3 trạng thái: thường, khóa, mở.
- Repair station có sprite.
- HUD sinh tồn đủ Pin, O2, HP, nhiệt độ, nước, độ no, lượt hiện tại.
- Mission panel có mục tiêu lớn, nhiệm vụ con, việc cần làm tiếp.
- Inventory popup có danh sách item.
- Crafting panel có công thức, nguyên liệu, nút chế tạo.
- Puzzle popup có câu hỏi, đáp án, hint, kết quả đúng/sai.
- AI chat panel có ô nhập, gửi, log, đóng.
- Visual feedback có nhặt item, mở cửa, craft, puzzle đúng/sai, hoàn thành nhiệm vụ, win/game over.
- Map đã chỉnh lại.
- Collision shapes đã thêm vào khung qua `scenes/collision_frames.tscn`.
